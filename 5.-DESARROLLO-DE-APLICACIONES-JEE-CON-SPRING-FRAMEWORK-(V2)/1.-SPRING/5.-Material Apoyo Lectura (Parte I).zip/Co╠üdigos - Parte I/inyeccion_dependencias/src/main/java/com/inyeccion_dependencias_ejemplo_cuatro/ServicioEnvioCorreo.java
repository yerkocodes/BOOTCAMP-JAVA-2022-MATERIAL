package com.inyeccion_dependencias_ejemplo_cuatro;

public class ServicioEnvioCorreo {
	public void enviarCorreo() {
		System.out.println("Enviar Correo");
	}
}
