package com.beansEjemplos.beansanotaciones;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.beansEjemplos.beansanotaciones.AppConfig;



@SpringBootApplication
public class BeansEjemplosApplication {

	public static void main(String[] args) {
		ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);

		Persona p = appContext.getBean(Persona.class);
		
		System.out.println(p.toString());
	}

}

