package com.inyeccion_dependencias_ejemplo_tres;


public class Main {

	public static void main(String[] args) {
	    ServicioCorreo servicio= new ServicioCorreo(
	    							new ServicioRegistroCorreo(),
	    							new ServicioEnvioCorreo()
	    						);
	    servicio.enviar();
  }
}
