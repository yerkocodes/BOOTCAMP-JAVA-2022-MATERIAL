package com.inyeccion_dependencias_ejemplo_uno;

public class ServicioCorreo {
	
	public void enviar() {
		System.out.println("Registrar correo");
		System.out.println("Enviar correo");
	}
	
}
