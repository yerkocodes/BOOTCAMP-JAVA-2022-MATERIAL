package com.inyeccion_dependencias_ejemplo_tres;

public class ServicioCorreo {
	
	ServicioRegistroCorreo servicio_registro;
	ServicioEnvioCorreo servicio_envio;
	
	public ServicioCorreo(ServicioRegistroCorreo servicio_registro, ServicioEnvioCorreo servicio_envio) {
		this.servicio_registro = servicio_registro;
		this.servicio_envio = servicio_envio;
	}
	
	public void enviar() {
		servicio_registro.registrarCorreo();
		servicio_envio.enviarCorreo();
	}
}
