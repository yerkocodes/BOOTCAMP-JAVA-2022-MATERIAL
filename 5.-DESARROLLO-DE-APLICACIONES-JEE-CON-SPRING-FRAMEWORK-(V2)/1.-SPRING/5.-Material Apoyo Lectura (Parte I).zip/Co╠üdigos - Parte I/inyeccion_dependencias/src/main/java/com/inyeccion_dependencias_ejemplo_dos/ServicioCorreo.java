package com.inyeccion_dependencias_ejemplo_dos;

public class ServicioCorreo {
	
	ServicioRegistroCorreo servicio_registro;
	ServicioEnvioCorreo servicio_envio;
	
	public ServicioCorreo() {
		this.servicio_registro = new ServicioRegistroCorreo();
		this.servicio_envio = new ServicioEnvioCorreo();
	}
	
	public void enviar() {
		servicio_registro.registrarCorreo();
		servicio_envio.enviarCorreo();
	}
}
