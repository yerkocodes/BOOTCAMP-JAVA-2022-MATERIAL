package com.inyeccion_dependencias_ejemplo_cinco;

public class ServicioEnvioCorreo implements IServicioEnvioCorreo{

	public void enviarCorreo() {

		System.out.println("Enviar Correo");
	}
	public void analizarCorreo() {

		System.out.println("Analizar Correo");
	}
	
}
