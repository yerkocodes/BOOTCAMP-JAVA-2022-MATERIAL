package com.inyeccion_dependencias_ejemplo_dos;

public class Main {

	public static void main(String[] args) {
	    ServicioCorreo servicio= new ServicioCorreo();
	    servicio.enviar();
  }
}
