package com.inyeccion_dependencias_ejemplo_cinco;

public interface IServicioEnvioCorreo {
	public void enviarCorreo();
	public void analizarCorreo();
}
