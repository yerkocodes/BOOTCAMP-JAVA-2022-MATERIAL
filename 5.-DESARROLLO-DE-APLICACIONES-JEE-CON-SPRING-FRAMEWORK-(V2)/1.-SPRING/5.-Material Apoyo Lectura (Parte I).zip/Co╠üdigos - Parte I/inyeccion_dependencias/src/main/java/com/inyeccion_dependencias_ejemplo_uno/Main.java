package com.inyeccion_dependencias_ejemplo_uno;

public class Main {

	public static void main(String[] args) {
	    ServicioCorreo servicio= new ServicioCorreo();
	    servicio.enviar();
  }
}
