package com.inyeccion_dependencias_ejemplo_dos;

public class ServicioRegistroCorreo {
	public void registrarCorreo() {
		System.out.println("Registrar correo");
	}
}
