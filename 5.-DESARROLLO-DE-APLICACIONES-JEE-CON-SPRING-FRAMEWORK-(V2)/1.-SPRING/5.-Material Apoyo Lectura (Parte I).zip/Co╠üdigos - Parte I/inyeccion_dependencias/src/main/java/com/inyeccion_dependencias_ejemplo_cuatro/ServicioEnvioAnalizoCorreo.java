package com.inyeccion_dependencias_ejemplo_cuatro;

public class ServicioEnvioAnalizoCorreo extends ServicioEnvioCorreo {
	
	public void enviarCorreo() {
		System.out.println("Analizo correo");
		super.enviarCorreo();
	}

}
