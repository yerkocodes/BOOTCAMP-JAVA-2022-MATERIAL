package com.micalculadora;

public class Calculadora{

	public static double suma (double a, double b) {
		return (a+b);
	}
	public static double multiplica (double a, double b) {
		return (a*b);
	}
	public static double resta (double a, double b) {
		return (a-b);
	}
	public static double divide (double a, double b) {
		return (a/b);
	}
	public static double resto (double a, double b) {
		return (a%b);
	}
}
