package com.micalculadora.pruebas;

import org.junit.Test;

import com.micalculadora.Calculadora;

import static org.junit.Assert.*;

public class CalculadoraPrueba {
	
	@Test
	public void prueba() {
		
		assertEquals(4,Calculadora.suma(2,2),0);
		
		assertEquals(4,Calculadora.multiplica(2,2),0);
		
		assertEquals(0,Calculadora.resta(2,2),0);
		
		assertEquals(1,Calculadora.divide(2,2),0);
		
		assertEquals(0,Calculadora.resto(2,2),0);
	}
}